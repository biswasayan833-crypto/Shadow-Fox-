
function showDetails(year) {
    const box = document.getElementById("details-box");

    const data = {
        "2008": {
            title: "2008 - Beginning Era 🟣",
            text: "KKR started their IPL journey under Sourav Ganguly. The team had a mixed season but built a massive fan base."
        },
        "2012": {
            title: "2012 - Champions 🏆",
            text: "KKR won their first IPL title under Gautam Gambhir. Manvinder Bisla played a match-winning knock in the final vs CSK."
        },
        "2014": {
            title: "2014 - Champions Again 🏆",
            text: "KKR lifted their second IPL trophy. Robin Uthappa dominated the season and the team had an incredible winning streak."
        },
        "2024": {
            title: "2024 - Champions 🏆🔥",
            text: "KKR won their third IPL title in 2024 with a dominant performance throughout the season. A complete team effort led them to glory, making it one of their most memorable campaigns."
        }
    };

    box.innerHTML = `
        <h3>${data[year].title}</h3>
        <p>${data[year].text}</p>
    `;
}